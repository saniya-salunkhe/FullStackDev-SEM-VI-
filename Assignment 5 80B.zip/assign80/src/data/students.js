export const studentsData = [
  {
    roll: "80",
    name: "Saniya Salunkhe",
    course: "Computer Science",
    semester: 6,
    enrolled: false
  },
  {
    roll: "47",
    name: "Sanika Mane",
    course: "Information Technology",
    semester: 6,
    enrolled: true
  },
  {
    roll: "11",
    name: "Yash Salunkhe",
    course: "MBA",
    semester: 3,
    enrolled: true
  },
  {
    roll: "68",
    name: "Shruti Patil",
    course: "Computer Science",
    semester: 6,
    enrolled: false
  },
  {
    roll: "13",
    name: "Harshada Yadav",
    course: "MBA",
    semester: 3,
    enrolled: true
  },
  {
    roll: "25",
    name: "Affrin Mulla",
    course: "BCA",
    semester: 4,
    enrolled: false
  },
  {
    roll: "75",
    name: "Aaryaman Patil",
    course: "Data Science",
    semester: 3,
    enrolled: true
  },
  {
    roll: "100",
    name: "Tanishka Salunkhe",
    course: "MBA",
    semester: 6,
    enrolled: true
  }
];