import React from "react";

const StudentCard = ({ student, onToggleStatus }) => {
  return (
    <div className="student-card">
      <h2 className="card-title">Student Profile</h2>

      <p><strong>Roll No :</strong> {student.rollNo}</p>
      <p><strong>Name :</strong> {student.name}</p>
      <p><strong>Course :</strong> {student.course}</p>
      <p><strong>Semester :</strong> {student.semester}</p>
      <p><strong>Status :</strong> {student.status}</p>

      <button onClick={onToggleStatus}>
        Toggle Status
      </button>
    </div>
  );
};

export default StudentCard;


