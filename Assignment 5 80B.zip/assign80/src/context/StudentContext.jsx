import React, { createContext, useReducer } from "react";
import { studentReducer } from "../reducer/studentReducer";
import { studentsData } from "../data/students";

export const StudentContext = createContext();

const initialState = {
  students: studentsData,
  role: "admin"
};

export const StudentProvider = ({ children }) => {

  const [state, dispatch] = useReducer(studentReducer, initialState);

  return (
    <StudentContext.Provider value={{ state, dispatch }}>
      {children}
    </StudentContext.Provider>
  );
};