export const studentReducer = (state, action) => {

  switch (action.type) {

    case "TOGGLE_STATUS":
      return {
        ...state,
        students: state.students.map(student =>
          student.roll === action.payload
            ? { ...student, enrolled: !student.enrolled }
            : student
        )
      };

    default:
      return state;
  }

};