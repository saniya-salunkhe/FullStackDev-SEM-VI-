import React, { useState } from "react";
import "./StudentRegForm.css";

const StudentForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    rollNumber: "",
    email: "",
    course: "",
    password: "",
  });

  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState("");

  // Validation Function
  const validate = (name, value) => {
    let error = "";

    switch (name) {
      case "name":
        if (!value.trim()) error = "Student Name is required";
        break;

      case "rollNumber":
        if (!value.trim()) {
          error = "Roll Number is required";
        } else if (!/^[a-zA-Z0-9]+$/.test(value)) {
          error = "Roll Number must be alphanumeric";
        }
        break;

      case "email":
        if (!value.trim()) {
          error = "Email is required";
        } else if (!/^\S+@\S+\.\S+$/.test(value)) {
          error = "Invalid email format";
        }
        break;

      case "course":
        if (!value) error = "Please select a course";
        break;

      case "password":
        if (!value) {
          error = "Password is required";
        } else if (value.length < 6) {
          error = "Password must be at least 6 characters";
        }
        break;

      default:
        break;
    }

    return error;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({ ...formData, [name]: value });

    const error = validate(name, value);
    setErrors({ ...errors, [name]: error });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    let newErrors = {};

    Object.keys(formData).forEach((field) => {
      const error = validate(field, formData[field]);
      if (error) newErrors[field] = error;
    });

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      setSuccessMessage("Registration Successful!");
      setFormData({
        name: "",
        rollNumber: "",
        email: "",
        course: "",
        password: "",
      });
    } else {
      setSuccessMessage("");
    }
  };

  return (
    <div className="container">
      <h2>Student Registration Form</h2>

      {successMessage && <div className="success">{successMessage}</div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Student Name : </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className={errors.name ? "error-input" : ""}
          />
          {errors.name && <p className="error">{errors.name}</p>}
        </div>

        <div className="form-group">
          <label>Roll Number : </label>
          <input
            type="text"
            name="rollNumber"
            value={formData.rollNumber}
            onChange={handleChange}
            className={errors.rollNumber ? "error-input" : ""}
          />
          {errors.rollNumber && <p className="error">{errors.rollNumber}</p>}
        </div>

        <div className="form-group">
          <label>Email Address : </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className={errors.email ? "error-input" : ""}
          />
          {errors.email && <p className="error">{errors.email}</p>}
        </div>

        <div className="form-group">
          <label>Course : </label>
          <select
            name="course"
            value={formData.course}
            onChange={handleChange}
            className={errors.course ? "error-input" : ""}
          >
            <option value="">-- Select Course --</option>
            <option value="BCA">BCA</option>
            <option value="BBA">BBA</option>
            <option value="BTech">BTech</option>
            <option value="MBA">MBA</option>
            <option value="MTech">MTech</option>
          </select>
          {errors.course && <p className="error">{errors.course}</p>}
        </div>

        <div className="form-group">
          <label>Password : </label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className={errors.password ? "error-input" : ""}
          />
          {errors.password && <p className="error">{errors.password}</p>}
        </div>

        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default StudentForm;
