import React, { useMemo } from "react";

function DashboardStats({ students }) {

  const stats = useMemo(() => {

    const enrolled = students.filter(s => s.enrolled).length;
    const notEnrolled = students.length - enrolled;

    return { enrolled, notEnrolled };

  }, [students]);

  return (

    <div className="stats-container">

      <div className="stat-box">
        <h3>Enrolled</h3>
        <p>{stats.enrolled}</p>
      </div>

      <div className="stat-box">
        <h3>Not Enrolled</h3>
        <p>{stats.notEnrolled}</p>
      </div>

    </div>

  );
}

export default DashboardStats;