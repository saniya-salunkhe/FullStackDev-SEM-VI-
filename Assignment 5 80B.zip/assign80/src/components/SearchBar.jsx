import React, { useRef, useEffect } from "react";

function SearchBar({ setSearch }) {

  const inputRef = useRef();

  useEffect(() => {
    inputRef.current.focus();
  }, []);

  return (

    <div className="search-container">

      <input
        ref={inputRef}
        className="search-input"
        placeholder="Search by name or roll..."
        onChange={(e) => setSearch(e.target.value)}
      />

    </div>

  );
}

export default SearchBar;