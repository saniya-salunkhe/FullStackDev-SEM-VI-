import React, { useRef } from "react";

function StudentCard({ student, toggleStatus }) {

  const previousStatus = useRef(student.enrolled);

  return (

    <div className="card">

      <h3>{student.name}</h3>

      <p><strong>Roll:</strong> {student.roll}</p>
      <p><strong>Course:</strong> {student.course}</p>
      <p><strong>Semester:</strong> {student.semester}</p>

      <p>
        <strong>Status:</strong>
        <span
          className={student.enrolled ? "status-enrolled" : "status-not"}
        >
          {student.enrolled ? " Enrolled" : " Not Enrolled"}
        </span>
      </p>

      <button
        className="toggle-btn"
        onClick={() => toggleStatus(student.roll)}
      >
        Toggle Status
      </button>

    </div>

  );
}

export default React.memo(StudentCard);