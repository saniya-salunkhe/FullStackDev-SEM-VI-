import React, {
  useContext,
  useState,
  useMemo,
  useCallback,
  useEffect
} from "react";

import { StudentContext } from "../context/StudentContext";
import StudentCard from "./StudentCard";
import SearchBar from "./SearchBar";
import DashboardStats from "./DashboardStats";

function StudentList() {

  const { state, dispatch } = useContext(StudentContext);
  const [search, setSearch] = useState("");

  useEffect(() => {
    console.log("Student status updated");
  }, [state.students]);

  const toggleStatus = useCallback((roll) => {

    const confirmChange = window.confirm("Change enrollment status?");

    if (confirmChange) {
      dispatch({
        type: "TOGGLE_STATUS",
        payload: roll
      });
    }

  }, [dispatch]);

  const filteredStudents = useMemo(() => {

    return state.students.filter(student =>
      student.name.toLowerCase().includes(search.toLowerCase()) ||
      student.roll.includes(search)
    );

  }, [search, state.students]);

  if (state.students.length === 0) {
    return <h2>No Student Data Available</h2>;
  }

  return (

    <div>

      <SearchBar setSearch={setSearch} />

      <DashboardStats students={state.students} />

      <div className="student-grid">

        {filteredStudents.map(student => (

          <StudentCard
            key={student.roll}
            student={student}
            toggleStatus={toggleStatus}
          />

        ))}

      </div>

    </div>

  );
}

export default StudentList;