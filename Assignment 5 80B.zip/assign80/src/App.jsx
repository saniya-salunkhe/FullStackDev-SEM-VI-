import React from "react";
import StudentList from "./components/StudentList";
import { StudentProvider } from "./context/StudentContext";
import "./App.css";

function App() {

  return (
    <StudentProvider>
      <div className="app-container">

        <h1 className="title">Student Profile Management System</h1>

        <StudentList />

      </div>
    </StudentProvider>
  );
}

export default App;