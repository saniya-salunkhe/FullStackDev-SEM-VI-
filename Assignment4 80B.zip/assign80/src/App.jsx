import React from "react";
import StudentForm from "./StudentRegForm";

function App() {
  return (
    <div>
      <StudentForm />
    </div>
  );
}

export default App;
