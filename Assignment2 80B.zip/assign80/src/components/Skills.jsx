import React from "react";

const Skills = () => {
  const skills = [
    "Programming Languages",
    "Teamwork",
    "Time Management",
    "Problem Solving",
    "Creativity",
    "Collaboration",
  ];

  return (
    <section id="skills">
      <h2>Skills</h2>
      <ul>
        {skills.map((skill, i) => (
          <li key={i}>{skill}</li>
        ))}
      </ul>
    </section>
  );
};

export default Skills;
