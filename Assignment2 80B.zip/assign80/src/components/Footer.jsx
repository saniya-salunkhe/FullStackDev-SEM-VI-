import React from "react";

const Footer = () => (
  <footer>
    <p>© 2026 Saniya Salunkhe. All Rights Reserved.</p>
  </footer>
);

export default Footer;
