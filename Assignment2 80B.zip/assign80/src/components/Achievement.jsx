import React from "react";

const Achievement = () => {
  return (
    <section id="achievement">
      <h2>Achievement</h2>
      <p>
        🏆 Secured <strong>2nd Place</strong> in the Web Development Hackathon 2025
        with teammate Sanika Mane. Sponsored by Walstar Technologies Pvt. Ltd.
      </p>
    </section>
  );
};

export default Achievement;
