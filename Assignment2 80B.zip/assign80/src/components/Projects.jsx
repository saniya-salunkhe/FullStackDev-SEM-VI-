import React from "react";

const Projects = () => {
  const projects = [
    {
      name: "Kolhapur Bike Rental",
      description:
        "A web-based bike rental platform that allows users to browse available bikes, check pricing, and book rentals online. Designed with a clean UI and responsive layout for better user experience.",
      tech: "HTML, CSS, JavaScript",
      github: "https://github.com/saniya-salunkhe/KolhapurBike-Rental",
    },
  ];

  return (
    <section id="projects">
      <h2>Projects</h2>

      {projects.map((project, index) => (
        <div key={index} className="project-card">
          <h3>{project.name}</h3>
          <p>{project.description}</p>
          <p><strong>Tech Stack:</strong> {project.tech}</p>

          <a
            href={project.github}
            target="_blank"
            rel="noreferrer"
            className="project-btn"
          >
            View on GitHub
          </a>
        </div>
      ))}
    </section>
  );
};

export default Projects;
