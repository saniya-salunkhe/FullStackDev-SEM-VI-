import React from "react";

const Header = () => {
  return (
    <header className="hero">
      <h1>Saniya Salunkhe</h1>
      <p>B.Tech (CSE) | Frontend Developer</p>
      <a href="#contact" className="btn">Contact Me</a>
    </header>
  );
};

export default Header;
