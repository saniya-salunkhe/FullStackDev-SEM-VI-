import React from "react";

const About = () => {
  return (
    <section id="about">
      <h2>About Me</h2>
      <p>
        I'm Saniya Salunkhe, a passionate and curious 3rd-year Computer Science Engineering student at D Y Patil School of Engineering & Management, Kolhapur. I enjoy building clean, user-friendly web interfaces and exploring modern frontend technologies. As a frontend developer, I work with HTML, CSS, and JavaScript, and love transforming ideas into real web experiences. I'm also part of the Google Developer Student Clubs (GDSC) Coding Team, where I collaborate on real-time projects and hackathons.
      </p>
    </section>
  );
};

export default About;
