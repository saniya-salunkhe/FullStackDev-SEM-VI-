import React from "react";

const Contact = () => {
  return (
    <section id="contact">
      <h2>Contact Me</h2>
      <p>Email: salunkhesaniya74@gmail.com</p>
      <p>Phone: +91 9970912404</p>
    </section>
  );
};

export default Contact;
