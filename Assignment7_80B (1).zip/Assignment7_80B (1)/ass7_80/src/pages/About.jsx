export default function About() {
  return (
    <div className="card">
      <h2>About</h2>
      <p>Student Profile Management System using React Router.</p>
      <p>College: D Y Patil School of Engineering & Management</p>
    </div>
  );
}
