import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

export default function EditStudent({ students, updateStudent }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const student = students.find(s => s.id === id);

  const [form, setForm] = useState(student || {});

  const handleChange = e => setForm({...form, [e.target.name]: e.target.value});

  const handleSubmit = e => {
    e.preventDefault();
    updateStudent(form);
    navigate(`/students/${id}`);
  };

  return (
    <div className="card">
      <h2>Edit Student</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" value={form.name} onChange={handleChange} />
        <input name="roll" value={form.roll} onChange={handleChange} />
        <input name="dept" value={form.dept} onChange={handleChange} />
        <input name="email" value={form.email} onChange={handleChange} />
        <input name="year" value={form.year} onChange={handleChange} />
        <input name="photo" value={form.photo} onChange={handleChange} />
        <button className="btn">Update</button>
      </form>
    </div>
  );
}