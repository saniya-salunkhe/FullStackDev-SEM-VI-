import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

export default function Login({ setRole, setCurrentUser, students }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    const user = students.find(
      (s) => s.email === email && s.password === password
    );

    if (user) {
      setRole("student");
      setCurrentUser(user);
      navigate("/students");
    } else {
      alert("Invalid student credentials");
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Login</h2>

        <input
          type="email"
          placeholder="Enter Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button className="btn btn-primary" onClick={handleLogin}>
          Student Login
        </button>

        {/* ADMIN BUTTON */}
        <button
          className="btn btn-success"
          onClick={() => {
            setRole("admin");
            navigate("/");
          }}
        >
          Admin Login
        </button>

        <p>
          New student? <Link to="/signup">Create Account</Link>
        </p>
      </div>
    </div>
  );
}
