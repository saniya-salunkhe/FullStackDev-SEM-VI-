import { useState } from "react";

export default function AddStudent({ addStudent }) {
  const [form, setForm] = useState({});

  const handleChange = e => setForm({...form, [e.target.name]: e.target.value});

  const handleSubmit = e => {
    e.preventDefault();
    addStudent(form);
  };

  return (
    <div className="card">
      <h2>Add Student</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" onChange={handleChange} />
        <input name="roll" placeholder="Roll" onChange={handleChange} />
        <input name="dept" placeholder="Department" onChange={handleChange} />
        <input name="email" placeholder="Email" onChange={handleChange} />
        <input name="year" placeholder="Year" onChange={handleChange} />
        <input name="photo" placeholder="Image URL" onChange={handleChange} />
        <button className="btn">Add</button>
      </form>
    </div>
  );
}