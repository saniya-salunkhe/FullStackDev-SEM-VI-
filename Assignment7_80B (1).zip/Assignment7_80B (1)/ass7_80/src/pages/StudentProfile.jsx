import { useParams, Link } from "react-router-dom";

export default function StudentProfile({ students }) {
  const { id } = useParams();
  const s = students.find(st => st.id === id);

  if (!s) return <h2>Not Found</h2>;

  return (
    <div className="card">
      <img src={s.photo} className="avatar-large" />
      <h2>{s.name}</h2>
      <p>Roll: {s.roll}</p>
      <p>Dept: {s.dept}</p>
      <p>Email: {s.email}</p>
      <p>Year: {s.year}</p>

      <Link to={`/edit-student/${s.id}`} className="btn">Edit</Link>
      <Link to="/students" className="btn">Back</Link>
    </div>
  );
}
