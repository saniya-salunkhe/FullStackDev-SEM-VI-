import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Signup({ setStudents, setRole, setCurrentUser, students }) {
  const [form, setForm] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    const newUser = { ...form, id: Date.now().toString() };
    setStudents([...students, newUser]);
    setCurrentUser(newUser);
    setRole("student");
    navigate("/students");
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Signup</h2>
        <form onSubmit={handleSubmit}>
          <input name="name" placeholder="Name" onChange={handleChange} />
          <input name="email" placeholder="Email" onChange={handleChange} />
          <input name="password" placeholder="Password" onChange={handleChange} />
          <input name="dept" placeholder="Department" onChange={handleChange} />
          <input name="division" placeholder="Division" onChange={handleChange} />
          <input name="year" placeholder="Year" onChange={handleChange} />
          <input name="photo" placeholder="Image URL" onChange={handleChange} />
          <button className="btn btn-success">Create Account</button>
        </form>
      </div>
    </div>
  );
}
