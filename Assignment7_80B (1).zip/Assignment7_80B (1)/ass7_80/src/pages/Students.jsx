import { Link } from "react-router-dom";

export default function Students({ students }) {
  return (
    <div>
      <h2>Students</h2>
      {students.map(s => (
        <div className="card" key={s.id}>
          <img src={s.photo} className="avatar" />
          <h3>{s.name}</h3>
          <p>Roll: {s.roll}</p>
          <p>Dept: {s.dept}</p>
          <Link to={`/students/${s.id}`} className="btn">View Profile</Link>
        </div>
      ))}
    </div>
  );
}