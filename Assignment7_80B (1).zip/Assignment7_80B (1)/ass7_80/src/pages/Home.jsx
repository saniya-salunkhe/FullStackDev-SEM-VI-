import { Link } from "react-router-dom";

export default function Home({ students }) {
  return (
    <div className="home">
      <div className="home-content">
        <h1 className="college">D Y Patil School of Engineering & Management</h1>
        <p>Welcome to Student Profile Management System</p>

        <h3>Top Students</h3>
        {students.slice(0,2).map(s => (
          <div className="card" key={s.id}>
            <img src={s.photo} className="avatar" />
            <h4>{s.name}</h4>
            <Link to={`/students/${s.id}`} className="btn">View</Link>
          </div>
        ))}
      </div>
    </div>
  );
}