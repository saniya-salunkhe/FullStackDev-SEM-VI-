export const initialStudents = [
  {
    id: "1",
    name: "Saniya Salunkhe",
    roll: "101",
    dept: "CSE",
    email: "saniya@gmail.com",
    year: "3rd",
    photo: "https://tse1.mm.bing.net/th/id/OIP.PqBYGErQeWQWhbA_VeUBDQHaHa?rs=1&pid=ImgDetMain&o=7&rm=3"
  },
  {
    id: "2",
    name: "Sanika Mane",
    roll: "102",
    dept: "CSE",
    email: "sanika567@gmail.com",
    year: "3rd",
    photo: "https://cdn-icons-png.flaticon.com/512/147/147135.png"
  },
  {
    id: "3",
    name: "Yash Salunkhe",
    roll: "11",
    dept: "MBA",
    email: "yash123@gmail.com",
    year: "2nd",
    photo: "https://tse1.explicit.bing.net/th/id/OIP.ZH-x4UnmQ3b4DXT0sLHI4wHaFN?rs=1&pid=ImgDetMain&o=7&rm=3"
  },
  {
    id: "4",
    name: "Shruti Patil",
    roll: "15",
    dept: "CSE",
    email: "shrutipatil123@gmail.com",
    year: "3rd",
    photo: "https://static.vecteezy.com/system/resources/previews/009/313/954/original/default-avatar-profile-in-flat-design-free-png.png"
  },
  {
    id: "5",
    name: "Priya Patil",
    roll: "19",
    dept: "CSE",
    email: "priyapatil879@gmail.com",
    year: "3rd",
    photo: "https://static.vecteezy.com/system/resources/previews/004/773/704/original/a-girl-s-face-with-a-beautiful-smile-a-female-avatar-for-a-website-and-social-network-vector.jpg"
  },
  {
    id: "6",
    name: "Swaraj Mane",
    roll: "102",
    dept: "BCA",
    email: "swaraj1234@gmail.com",
    year: "2nd",
    photo: "https://img.freepik.com/premium-vector/man-avatar-profile-picture-isolated-background-avatar-profile-picture-man_1293239-4841.jpg"
  }
];