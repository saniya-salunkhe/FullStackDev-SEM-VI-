import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Students from "./pages/Students";
import StudentProfile from "./pages/StudentProfile";
import AddStudent from "./pages/AddStudent";
import EditStudent from "./pages/EditStudent";
import About from "./pages/About";
import PageNotFound from "./pages/PageNotFound";
import { initialStudents } from "./data/students";

export default function App() {
  const [students, setStudents] = useState(initialStudents);

  const addStudent = (student) => {
    setStudents([...students, { ...student, id: Date.now().toString() }]);
  };

  const updateStudent = (updated) => {
    setStudents(students.map(s => s.id === updated.id ? updated : s));
  };

  return (
    <>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home students={students} />} />
          <Route path="/students" element={<Students students={students} />} />
          <Route path="/students/:id" element={<StudentProfile students={students} />} />
          <Route path="/add-student" element={<AddStudent addStudent={addStudent} />} />
          <Route path="/edit-student/:id" element={<EditStudent students={students} updateStudent={updateStudent} />} />
          <Route path="/about" element={<About />} />
          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </div>
    </>
  );
}
